a=int(input("Ingrese su nota definitiva"))
if a>=4:
    print("Felicitaciones")
else:
    print("Perdiste, mejora para la próxima")