a=int(input("Ingres su primer número"))
b=int(input("Ingrese su segundo número"))
c=int(input("Ingrese su tercer número"))
d=(a+b+c)/3
print("El promedio de los 3 números es ", d)