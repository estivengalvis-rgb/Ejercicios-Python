a=int(input("Ingrese un número"))
if a>3.5 and a<=7.8:
    print("Su número está dentro del rango")
else:
    print("Su número no está dentro del rango")