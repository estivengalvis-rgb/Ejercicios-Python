x=int(input("Ingrese un número "))
if x==5:
    print("Es 5")
elif x==6:
    print("Es 6")
elif x==7:
    print("Es 7")
else:
    print("No es ninguna")