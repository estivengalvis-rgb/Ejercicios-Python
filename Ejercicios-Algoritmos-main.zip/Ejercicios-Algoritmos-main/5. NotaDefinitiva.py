a=int(input("Ingrese la primera nota"))
b=int(input("Ingrese la segunda nota"))
c=int(input("Ingrese la tercera nota"))
d=int(input("Ingrese la cuarta nota"))
e=a+b+c+d
f=e/4
print("Su nota definitiva es ", f)