a=str(input("Ingrese la palabra A"))
b=str(input("Ingrese la palabra B"))
c=a
a=b
b=c
print("Después del intercambio")
print("La palabra A es ", a)
print("La palabra B es ", b)