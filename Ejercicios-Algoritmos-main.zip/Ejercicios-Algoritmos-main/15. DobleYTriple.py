a=int(input("Ingrese un número"))
b=2*a
c=3*a
print("El doble de ese número es ", b)
print("El triple de ese número es ", c)