# Ejercicios-Algoritmos
Ejercicios de P-Seint. Este repositorio contiene mis soluciones a los ejercicios vistos en clase.
- Lenguaje: PSeInt / Python
- Curso: Algoritmos y Programación
- Profesor: Norbey Danilo Muñoz
-git add .
-git commit -m "Subo mis primeros ejercicios"
-git push
