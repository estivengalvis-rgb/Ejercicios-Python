a=10
b=5
c=a/b if b!=0 else -1
print(c)