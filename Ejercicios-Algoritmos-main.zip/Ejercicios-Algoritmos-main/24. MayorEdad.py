a=str(input("Ingrese su nombre "))
b=int(input("Ingrese su edad"))
if b>=18:
    print("Eres mayor de edad")
else:
    print("Eres menor de edad")
print("Eres ", a, " y tienes ", b, " años")