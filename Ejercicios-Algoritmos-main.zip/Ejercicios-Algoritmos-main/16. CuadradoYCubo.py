a=int(input("Ingrese un número"))
b=a**2
c=a**3
print("El cuadrado del número es ", b)
print("El cubo del número es ", c)