a=int(input("Ingrese el primer número"))
b=int(input("Ingrese el segundo número"))
c=a%b
print("El módulo entre los 2 números es ", c)