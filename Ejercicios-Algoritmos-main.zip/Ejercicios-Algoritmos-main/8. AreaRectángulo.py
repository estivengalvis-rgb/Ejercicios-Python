a=int(input("Ingrese la base del rectángulo"))
b=int(input("Ingrese la altura del rectaangulo"))
c=a*b
print("El área del rectnagulo es ", c)
d=(2*a)+(2*b)
print("El perímetro del rectangulo es ", d)