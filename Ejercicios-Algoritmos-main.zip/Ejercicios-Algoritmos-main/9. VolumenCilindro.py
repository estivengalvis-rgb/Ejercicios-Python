import math
a=int(input("Ingrese el radio del cilindro"))
b=int(input("Ingrese la altura del cilindro"))
c=math.pi*a**2*b
print("El volumen del cilindro es ", c)