import math
a=int(input("Ingrese el primer cateto"))
b=int(input("Ingrese el segundo cateto"))
c=math.sqrt(a**2+b**2)
print("La hipotenusa es ", c)