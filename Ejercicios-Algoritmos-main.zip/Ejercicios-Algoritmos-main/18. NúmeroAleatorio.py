import random
a=random.randint(0,200)
print("El número aleatorio es ", a)
b=a*0.3
c=a+b
print("El número aleatorio elevado un 30% es ", c)
