import random
a=random.randint(10,50)
print("El número entre 10-50 es ", a)
b=a*0.15
c=a-b
print("El número disminuido un 15% es ", c)