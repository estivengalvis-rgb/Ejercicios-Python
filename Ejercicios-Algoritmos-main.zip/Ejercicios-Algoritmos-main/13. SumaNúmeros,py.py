a=int(input("Ingrese el primer número"))
b=int(input("Ingrese el segundo número"))
c=a+b
print("La suma de los 2 números es ", c)