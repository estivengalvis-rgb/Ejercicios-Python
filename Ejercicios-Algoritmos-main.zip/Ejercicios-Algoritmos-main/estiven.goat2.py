a=4
b=2
if b!=0:
    print(a/b)
    print("Dentro if")
print("Fuera if")
