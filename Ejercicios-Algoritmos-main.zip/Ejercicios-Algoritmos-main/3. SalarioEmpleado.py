a=int(input("Ingrese sus horas trabajadas"))
b=int(input("Ingrese el valor de cada"))
c=a*b
print("Su salario es ",c)