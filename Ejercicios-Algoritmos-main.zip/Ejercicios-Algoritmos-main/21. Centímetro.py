a=int(input("Ingrese un número en cm"))
b=a/91.44
c=a/100
d=a/30.48
e=a/2.54
print("El valor en yardas es ", b)
print("El valor en metros es ", c)
print("El valor en pies es ", d)
print("El valor en pulgadas es ", e)