x=int(input("Ingrese un número "))
print("Es 5" if x==5 else "No es 5")