a=10
if a>5 and a<15:
    print("Mayor que 5 y menor que 15")