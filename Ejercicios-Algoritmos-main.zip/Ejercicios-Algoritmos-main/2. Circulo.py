import math
a=int(input("Ingrese el radio del círculo"))
b=math.pi*a**2
print ("El area del círculo es ", b)
c=2*math.pi*a
print ("El perimetro es ", c)