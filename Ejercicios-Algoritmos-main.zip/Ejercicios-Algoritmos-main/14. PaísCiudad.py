a=str(input("Ingrese el país"))
b=str(input("Ingrese su capital"))
print("La capital de ", a, " es ", b)