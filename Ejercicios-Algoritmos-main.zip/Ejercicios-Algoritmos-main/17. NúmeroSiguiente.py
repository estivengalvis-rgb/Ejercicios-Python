a=int(input("Ingrese un número"))
b=a+1
print("El número que le sigue es ", b)