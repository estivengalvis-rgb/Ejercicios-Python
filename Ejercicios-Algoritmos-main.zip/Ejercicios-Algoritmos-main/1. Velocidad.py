a=int(input("Ingrese la distancia"))
b=int(input("Ingrese el tiempo"))
v=a/b
print ("La velocidad es",v)