a=int(input("Ingrese el primer número "))
b=int(input("Ingrese el segundo número "))
if a>b:
    print(a, " es mayor que ", b)
elif b>a:
    print(b, " es mayor que ", a)
else:
    print("Los dos números son iguales")