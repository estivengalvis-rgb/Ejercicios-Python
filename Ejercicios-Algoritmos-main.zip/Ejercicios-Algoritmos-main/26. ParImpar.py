a=int(input("Ingrese un número"))
if a%2==0:
    print("Su número es par")
else:
    print("Su número es impar")