a=4
b=0
if b!=0:
    print(a/b)
else:
    print("No se puede dividir entre 0")