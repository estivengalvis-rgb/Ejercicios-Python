a=int(input("Ingrese su salario"))
b=a*0.04
print("Su aporte de pensión es ", b)
c=a*0.04
print("Su aporte de salud es ", c)
d=a-b-c
print("El dinero que tiene ahora es ", d)