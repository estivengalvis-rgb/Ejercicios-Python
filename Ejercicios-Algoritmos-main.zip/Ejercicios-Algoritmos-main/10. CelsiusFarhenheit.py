a=int(input("Ingrese la temperatura en Celsius"))
b=(9/5)*a+32
print("La temperatura en Fahrenheit es ", b)
